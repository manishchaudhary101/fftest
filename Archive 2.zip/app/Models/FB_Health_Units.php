<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class FB_Health_Units extends Model
{
    protected $table = 'Health_Units_Enum';
    public $timestamps = false;
}
