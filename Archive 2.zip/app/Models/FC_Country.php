<?php
/**
 * Created by PhpStorm.
 * User: Prakhar sharma
 * Date: 21-05-2019
 * Time: 09:53
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class FC_Country extends Model{

    protected $table = 'FC_Country';
}