<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Health_Tags_Enum extends Model
{
    //
    protected $table = 'Health_Tags_Enum';
    public $timestamps = false;
    
}
