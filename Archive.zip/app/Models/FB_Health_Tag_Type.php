<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class FB_Health_Tag_Type extends Model
{
    protected $table = 'Health_Tag_Type_Enum';
    public $timestamps = false;
}
